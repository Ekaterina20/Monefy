<?php $__env->startSection('title', 'Monefy - удобный учет расходов'); ?>

<?php $__env->startSection('content'); ?>

        <!-- Dashboard Header Section    -->
    <section class="dashboard-header">
        <div class="container-fluid">
            <div class="row">
            </div>
        </div>
    </section>

    <!-- Projects Section-->
    <section class="projects no-padding-top">
        <div class="container-fluid">
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\resources\views/admin/index.blade.php ENDPATH**/ ?>