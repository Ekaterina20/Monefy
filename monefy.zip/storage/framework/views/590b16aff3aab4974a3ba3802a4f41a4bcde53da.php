<?php $__env->startSection('title', 'Новая категория доходов'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">

            <?php echo Form::open(['action'=>'Admin\IncomesController@store', 'method'=>'put', 'class'=>'form-horizontal', 'files'=>true]); ?>

            <div class="form-group row">

                
                <?php echo Form::label('name', 'Наименование', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">

                    
                    <?php echo Form::text('name', null, ['class'=> $errors->has('name') ? 'form-control is-invalid':'form-control']); ?>


                    
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            

            <div class="form-group row">
                <?php echo Form::label('icon', 'Иконка', ['class' => 'col-sm-10 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::file('icon', ['class'=> 'form-control'] ); ?>

                </div>
            </div>

            
            <div class="form-group row">
                <label for="exampleInputEmail1">Цвет</label>
                <input type="color" name="color" class="form-control" id="exampleInputEmail1" placeholder="">
            </div>

            <?php echo Form::submit('Создать', ['class'=> 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\files\resources\views/admin/incomes/create.blade.php ENDPATH**/ ?>