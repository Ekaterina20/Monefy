<?php $__env->startSection('title', 'Добавьте новый доход'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">

            <?php echo Form::open(['url'=>'api/incomes/store', 'method'=>'put', 'class'=>'form-horizontal', 'files'=>true]); ?>


            <div class="form-group row">
                <?php echo Form::label('name', 'Наименование', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>


                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('income_id', 'Категория доходов', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">

                    <?php echo Form::select('income_id',$incomes, null, ['class'=> 'form-control']); ?>


                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('amount', 'Сумма', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::text('amount', null, ['class'=> 'form-control']); ?>

                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('comment', 'Комментарий', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::text('comment', null, ['class'=> 'form-control']); ?>

                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('icon', 'Иконка', ['class' => 'col-sm-10 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::file('icon', ['class'=> 'form-control'] ); ?>

                </div>
            </div>

            
            <div class="form-group row">
                <label for="exampleInputEmail1">Цвет</label>
                <input type="color" name="color" class="form-control" id="exampleInputEmail1" placeholder="">
            </div>

            <?php echo Form::submit('Создать', ['class'=> 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('api.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\resources\views/api/incomes/create.blade.php ENDPATH**/ ?>