<?php $__env->startSection('title', 'Изменение расхода'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">

            <?php echo Form::model($expense_site, ['url'=>"api/expenses/{$expense_site->slug}/edit", 'method'=>'post', 'class'=>'form-horizontal', 'files'=>true]); ?>


            <div class="form-group row">
                <?php echo Form::label('name', 'Наименование', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>

                </div>
            </div>

            

            <img style="background-color: <?php echo e($expense_site->color); ?>" src="<?php echo e(url("images/{$expense_site->icon}")); ?>" class="img-fluid my-4">

            <div class="form-group row">
                <?php echo Form::label('icon', 'Изображение', ['class' => 'col-sm-10 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::file('icon', ['class'=> 'form-control'] ); ?>

                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('expense_id', 'Категория расходов', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::select('expense_id',$expenses, null, ['class'=> 'form-control']); ?>

                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('amount', 'Сумма', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::text('amount', null, ['class'=> 'form-control']); ?>

                </div>
            </div>

            <div class="form-group row">
                <?php echo Form::label('comment', 'Комментарий', ['class'=>'col-sm-2 form-control-label']); ?>

                <div class="col-sm-10">
                    <?php echo Form::textarea('comment', null, ['class'=> 'form-control']); ?>


                </div>
            </div>

            
            <div class="form-group row">
                <label for="exampleInputEmail1">Цвет</label>
                <input type="color" name="color" class="form-control" id="exampleInputEmail1" placeholder="">
            </div>

            <?php echo Form::submit('Изменить', ['class'=> 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('api.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\resources\views/api/expenses/edit.blade.php ENDPATH**/ ?>