<?php $__env->startSection('title', 'Доходы'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <p class="alert alert-success"> <?php echo e(session('status')); ?> </p>
        <?php endif; ?>
    
    <a class="btn btn-primary admin-btn-create" href="<?php echo e(url('admin/incomes/create')); ?>">Добавить категорию доходов</a>

    <div class="card">
        <?php if($incomes->first()): ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Иконка</th>
                    <th>Название</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img style="background-color: <?php echo e($income->color); ?>" src="<?php echo e(url("files/storage/app/{$income->icon}")); ?>"
                                 class="img-fluid admin-img" width="100" height="100">
                        </td>
                        <td style="color: <?php echo e($income->color); ?>"> <?php echo e($income->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="alert alert-info"> Доходов не существует </p>
        <?php endif; ?>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\files\resources\views/admin/incomes/index.blade.php ENDPATH**/ ?>