<?php $__env->startSection('title', 'Monefy - удобный учет расходов'); ?>

<?php $__env->startSection('content'); ?>

        <!-- Dashboard Header Section    -->
    <section class="dashboard-header">
        <div class="container-fluid">
            <div class="row">
            </div>
        </div>
    </section>

        <!-- Projects Section-->

        

        <div class="card">
            <table class="table">
                <thead>
            <tr>
                <th>Ваш текущий баланс</th>
                <th><?php echo e($balance); ?> сом</th>
            </tr>
                </thead>
                </table>
        </div>

        <div class="card">
            <strong>История платежей</strong><br>
            <table class="table">
                <thead>
                <tr>
                    <th>Иконка</th>
                    <th>Название</th>
                    <th>Сумма</th>
                    <th>Дата</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $expense_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td>
                            <img style="background-color: <?php echo e($expense_site->color); ?>" src="<?php echo e(url("images/{$expense_site->icon}")); ?>"
                                 class="img-fluid admin-img" width="100" height="100">
                        </td>
                        <td><?php echo e($expense_site->name); ?></td>
                        <td><?php echo e($expense_site->amount); ?> сом</td>
                        <td><?php echo e(\Carbon\Carbon::parse($expense_site->created_at)->format('d m Y')); ?></td>
                       </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                        <?php $__currentLoopData = $income_sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income_site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td>
                                    <img style="background-color: <?php echo e($income_site->color); ?>" src="<?php echo e(url("images/{$income_site->icon}")); ?>"
                                         class="img-fluid admin-img" width="100" height="100">
                                </td>
                                <td><?php echo e($income_site->name); ?></td>
                                <td><?php echo e($income_site->amount); ?> сом</td>
                                <td><?php echo e(\Carbon\Carbon::parse($income_site->created_at)->format('d m Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('api.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\monefy\resources\views/api/index.blade.php ENDPATH**/ ?>